------------------------------------------------------------
OpenText RightFax Release Notes
------------------------------------------------------------

Release Notes for this RightFax product are available on the 
OpenText Knowledge Center. This document contains important
information about this product version and may include
documentation changes and additions that were not available
at the time of publication.

To view or download the Release Notes for this product, go to:

https://knowledge.opentext.com/knowledge/cs.dll?func=ll&objId=16513455&objAction=browse&viewType=1

and then open the folder appropriate to this product version.
The Release Notes will be posted on this page along with other
documentation.

